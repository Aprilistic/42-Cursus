/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   routing_bonus.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinheo <jinheo@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/28 15:23:39 by jinheo            #+#    #+#             */
/*   Updated: 2022/08/28 16:34:04 by jinheo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex_bonus.h"

void	open_source_file(t_metadata *data)
{
	if (access(data->argv[data->cmd_idx - 1], R_OK) < 0)
		return ;
	dup2(open(data->argv[data->cmd_idx - 1], O_RDONLY), STDIN_FILENO);
}

void	connect_two_children_processes(t_metadata *data)
{
	if ((data->cmd_idx % 2) == 0)
	{
		dup2(data->pipe_2[0], STDIN_FILENO);
		close(data->pipe_2[0]);
		close(data->pipe_2[1]);
		dup2(data->pipe_1[1], STDOUT_FILENO);
		close(data->pipe_1[0]);
		close(data->pipe_1[1]);
	}
	else
	{
		dup2(data->pipe_1[0], STDIN_FILENO);
		close(data->pipe_1[0]);
		close(data->pipe_1[1]);
		dup2(data->pipe_2[1], STDOUT_FILENO);
		close(data->pipe_2[0]);
		close(data->pipe_2[1]);
	}
}

void	close_destination_file(t_metadata *data)
{
	dup2(open(data->argv[data->cmd_idx + 1],
			O_CREAT | O_TRUNC | O_WRONLY, 0777), STDOUT_FILENO);
}
