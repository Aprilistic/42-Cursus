/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex_bonus.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinheo <jinheo@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/24 19:32:41 by jinheo            #+#    #+#             */
/*   Updated: 2022/08/28 16:15:12 by jinheo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex_bonus.h"

void	child1_process(int pid, t_metadata *data)
{
	if (pid < 0)
	{
		perror("fork() failed");
		exit(1);
	}
	if (pid == 0)
	{
		connect_two_children_processes(data);
		if (data->cmd_idx == 2)
			open_source_file(data);
		execute_command(data->argv[data->cmd_idx], data->envp);
	}
}

void	child2_process(int pid, t_metadata *data)
{
	if (pid < 0)
	{
		perror("fork() failed ");
		exit(1);
	}
	if (pid == 0)
	{
		connect_two_children_processes(data);
		if (data->cmd_idx == data->argc - 2)
			close_destination_file(data);
		execute_command(data->argv[data->cmd_idx], data->envp);
	}
}

int	main(int argc, char **argv, char **envp)
{
	t_metadata	data;
	pid_t		pid[2];
	int			pipe_1[2];
	int			pipe_2[2];
	int			cmd_idx;

	if (pipe(pipe_1) == -1 || pipe(pipe_2) == -1)
		perror("pipe() failed ");
	pid[0] = fork();
	if (pid[0] > 0)
		pid[1] = fork();
	set_initial_metadata(&data, argc, argv, envp);
	set_ipc_metadata(&data, pipe_1, pipe_2);
	cmd_idx = 2;
	while (cmd_idx < argc - 1)
	{
		data.cmd_idx = cmd_idx;
		if (cmd_idx % 2)
		{
			child2_process(pid[1], &data);
			waitpid(pid[1], NULL, 0);
		}
		else
		{
			child1_process(pid[0], &data);
			waitpid(pid[0], NULL, 0);
		}
		cmd_idx++;
	}
	close(pipe_1[0]);
	close(pipe_1[1]);
	close(pipe_2[0]);
	close(pipe_2[1]);
	return (0);
}
