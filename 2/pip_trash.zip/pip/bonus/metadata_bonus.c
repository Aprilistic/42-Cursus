/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   metadata_bonus.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinheo <jinheo@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/28 15:11:46 by jinheo            #+#    #+#             */
/*   Updated: 2022/08/28 15:21:03 by jinheo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex_bonus.h"

void	set_initial_metadata(t_metadata *data, int argc,
			char **argv, char **envp)
{
	data->argc = argc;
	data->argv = argv;
	data->envp = envp;
}

void	set_ipc_metadata(t_metadata *data, int *pipe_1, int *pipe_2)
{
	data->pipe_1 = pipe_1;
	data->pipe_2 = pipe_2;
}
