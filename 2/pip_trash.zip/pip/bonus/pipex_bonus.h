/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex_bonus.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinheo <jinheo@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/24 19:31:45 by jinheo            #+#    #+#             */
/*   Updated: 2022/08/28 16:13:23 by jinheo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PIPEX_BONUS_H
# define PIPEX_BONUS_H

# include "../libft/libft.h"
# include <fcntl.h>
# include <stdlib.h>
# include <unistd.h>
# include <stdio.h>

typedef struct s_metadata
{
	int		argc;
	int		cmd_idx;
	int		*pipe_1;
	int		*pipe_2;
	char	**argv;
	char	**envp;
}	t_metadata;

void	execute_command(char *command, char **envp);
void	set_initial_metadata(t_metadata *data, int argc,
			char **argv, char **envp);
void	set_ipc_metadata(t_metadata *data, int *pipe_1, int *pipe_2);

void	open_source_file(t_metadata *data);
void	connect_two_children_processes(t_metadata *data);
void	close_destination_file(t_metadata *data);

#endif
