/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   common.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinheo <jinheo@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/24 13:16:47 by jinheo            #+#    #+#             */
/*   Updated: 2022/08/24 13:19:14 by jinheo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

static void	send_ch(int pid, char ch)
{
	int	bit_sent;

	bit_sent = 0;
	while (bit_sent < 8)
	{
		if ((ch >> bit_sent) & 1)
			kill((pid_t)pid, SIGUSR1);
		else
			kill((pid_t)pid, SIGUSR2);
		usleep(10);
		bit_sent++;
	}
}

void	send_str(int pid, char *str)
{
	int	idx;

	idx = 0;
	while (1)
	{
		send_ch(pid, str[idx]);
		if (!str[idx])
			break ;
		idx++;
	}
}
