/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinheo <jinheo@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/23 13:53:24 by jinheo            #+#    #+#             */
/*   Updated: 2022/08/24 14:01:55 by jinheo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

int	main(int argc, char **argv)
{
	int		server_pid;
	char	*message;

	if (argc != 3)
	{
		ft_printf("Invalid parameters...\n");
		ft_printf("Sending aborted.\n");
		exit(0);
	}
	server_pid = ft_atoi(argv[1]);
	message = argv[2];
	ft_printf("Message to be sent : %s\n", message);
	send_str(server_pid, message);
	return (0);
}
