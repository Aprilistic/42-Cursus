/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client_bonus.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinheo <jinheo@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/23 13:53:24 by jinheo            #+#    #+#             */
/*   Updated: 2022/08/24 14:07:18 by jinheo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk_bonus.h"

int	main(int argc, char **argv)
{
	struct sigaction	act;
	int					client_pid;
	int					server_pid;
	char				*client_pid_str;
	char				*message;

	if (argc != 3)
	{
		ft_printf("Invalid parameters...\n");
		ft_printf("Sending aborted.\n");
		exit(0);
	}
	client_pid = (int)getpid();
	server_pid = ft_atoi(argv[1]);
	message = argv[2];
	ft_printf("Client PID : %d\n", client_pid);
	client_pid_str = ft_itoa(client_pid);
	send_str(server_pid, "Receiving message from ");
	send_str(server_pid, client_pid_str);
	free(client_pid_str);
	ft_printf("Message to be sent : %s\n", message);
	send_str(server_pid, message);
	return (0);
}
