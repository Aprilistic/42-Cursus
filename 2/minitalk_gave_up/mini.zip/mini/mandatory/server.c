/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   server.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinheo <jinheo@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/23 14:24:14 by jinheo            #+#    #+#             */
/*   Updated: 2022/08/24 11:31:01 by jinheo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void	handler(int signo)
{
	static char	ch = 0;
	static int	idx = 0;

	if (signo == (int)SIGUSR1)
		ch |= (1 << idx);
	idx++;
	if (idx == 8)
	{
		if (ch == 127)
			write(1, "\n", 1);
		else
			write(1, &ch, 1);
		ch = 0;
		idx = 0;
	}
}

int	main(void)
{
	struct sigaction	act;

	sigemptyset(&act.sa_mask);
	act.__sigaction_u.__sa_handler = handler;
	act.sa_flags = SA_SIGINFO;
	ft_printf("Server launched...\n");
	ft_printf("Server PID : %d\n", (int)getpid());
	if (-1 == sigaction(SIGUSR1, &act, NULL)
		|| -1 == sigaction(SIGUSR2, &act, NULL))
	{
		write(2, "sigaction() error!\n", 19);
		exit(1);
	}
	while (1)
		;
	return (0);
}
