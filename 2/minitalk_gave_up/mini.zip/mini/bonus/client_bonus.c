/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client_bonus.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinheo <jinheo@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/23 13:53:24 by jinheo            #+#    #+#             */
/*   Updated: 2022/08/24 12:58:03 by jinheo           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk_bonus.h"

void	send_ch(int pid, char ch)
{
	int	bit_sent;

	bit_sent = 0;
	while (bit_sent < 8)
	{
		if ((ch >> bit_sent) & 1)
			kill((pid_t)pid, SIGUSR1);
		else
			kill((pid_t)pid, SIGUSR2);
		usleep(10);
		bit_sent++;
	}
}

int	main(int argc, char **argv)
{
	int		client_pid;
	int		server_pid;
	char	*message;
	int		idx;

	if (argc != 3)
	{
		ft_printf("Invalid parameters...\n");
		ft_printf("Sending aborted.\n");
		exit(0);
	}
	client_pid = (int)getpid();
	server_pid = atoi(argv[1]);
	message = argv[2];
	ft_printf("Client PID : %d\n", client_pid);
	ft_printf("Message to be sent : %s\n", message);
	idx = 0;
	while (1)
	{
		send_ch(server_pid, message[idx]);
		if (!message[idx])
			break ;
		idx++;
	}
}
